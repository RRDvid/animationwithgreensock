# tweenmax-dev-test
This is a Banner dev test I did for one of my job application.

Open index.html

DISCLAIMER: I dont own any of the pictures I used in this project and none of the information are true - all were provided for me. This was solely for testing as part of a job application.

