
var tl,
imagesLoaded = false,
backup = false;

$(document).ready(function(){
preloadAssets();
});

function preloadAssets() {

var i = [
  "logo_aa.svg",
  "logo-qantas-colour.svg",
  "logo-qantas-mono.svg",
  "shape-mask.svg",
  "shape-red.svg",
  "shape-blue.svg",
  "shape-red-end-frame.svg",
  "shape-red-end-frame2.svg",
  "shape-white.svg"
];

preloadimages(i).done(function (images) {

    imagesLoaded = true;
    setTimeout(beginAnimation,2100);

})
}




//ANIMATION CODES
function beginAnimation(){
   const vid  = document.querySelector('#video-el'),
      banner  = document.querySelector('.banner'),
bannerContainer = document.querySelector('.container'),
       f1copy = document.querySelector('#f1-copy'),
       f2copy = document.querySelector('#f2-copy'),
    blueShape = document.querySelector('#blue-shape'),
    redShape  = document.querySelector('#red-shape'),
   whiteShape = document.querySelector('#white-shape'),
    maskShape = document.querySelector('#mask-shape'),
   qantasMono = document.querySelector('#qantas-logo-mono'),
   qantasColor= document.querySelector('#qantas-logo-colour'),
       aalogo = document.querySelector('#aa-logo'),
        terms = document.querySelector('.terms-wrapper'),
       loader = document.querySelector('.loader'),
       f3copy = document.querySelector('#f3-copy'),
      divider =  document.querySelector('#logo-divider'),
        btn   =  document.querySelector('.button'),
       shadow =  document.querySelector('#red-shape-end-frame2')
;



    console.log("start animation");

    // YOUR CODE STARTS HERE




}


// PRE-LOAD IMAGES FUNCTIONALITY ------------------------------------------------------------
function preloadimages(arr) {

    var newimages = [],
        loadedimages = 0
    var postaction = function () {}
    var arr = (typeof arr != "object") ? [arr] : arr

    function imageloadpost() {
        loadedimages++
        if (loadedimages == arr.length) {
            postaction(newimages) //call postaction and pass in newimages array as parameter
        }
    }
    for (var i = 0; i < arr.length; i++) {
        newimages[i] = new Image()
        newimages[i].src = arr[i]
        newimages[i].onload = function () {
            imageloadpost()
        }
        newimages[i].onerror = function () {
            imageloadpost()
        }
    }
    return { //return blank object with done() method
        done: function (f) {
            postaction = f || postaction //remember user defined callback functions to be called when images load
        }
    }
}
